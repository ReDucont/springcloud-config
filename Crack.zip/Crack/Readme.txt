1. Install DbVisualizer, run in trial mode and close.
2. Copy "dbvis.license" to "C:\Users\%username%\.dbvis"
3. Copy "dbvisualizer-agent.jar" to "C:\Program Files\DbVisualizer\"
4. Open "dbvis.vmoptions" from program folder and add this line:

-javaagent:C:\Program Files\DbVisualizer\dbvisualizer-agent.jar

Done.
=================